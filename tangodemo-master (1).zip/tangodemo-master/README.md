# Tango - Demo test repository

The Tango demo repo includes YAML files for Automation blueprints and K8s deployment and environment specifcations used by the Pipeline service.

Git webhooks can be configured to execute any user-modelled pipeline which is activated on the Pipeline service. Multiple webhooks can be configured for select Git events, which can be further filtered based on the commit file path/name in the Pipeline service Trigger objects.
